package com.estelle.hangman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstelleHangmanApplicationTests {

	@Test
	void contextLoads() {
	}

}
